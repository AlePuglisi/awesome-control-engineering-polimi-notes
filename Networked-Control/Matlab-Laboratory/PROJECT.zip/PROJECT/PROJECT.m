%% PROJECT, Three tanks system 

%% 1) MODELLING
% system state space matrix description:
Atot=[-1  0  0
       1 -1  0
       0  1 -1];

Ctot=eye(3);

Btot=[1  0
      0  1
      0  0];

%discrete time realization
h = 0.01; % sampling time, to chose wisely according to system dynamic
[Ftot,Gtot,Htot,Ltot,h]=ssdata(c2d(ss(Atot,Btot,Ctot,[]),h));

% System decomposition:
N = 2; %number of subsystems, (1)first tank, (2)second+third tank

for i=1:N
    % continuous time decomposition
    B{i} = Btot(:,i);
    C{i} = Ctot(i:2*i-1,:);
    % discrete time decomposition 
    G{i} = Gtot(:,i);
    H{i} = Htot(i:2*i-1,:);
end

%% 2) ANALYSIS
% Open Loop analysis:
% CONTROL STRUCTURES
ContStructure_centralized = ones(N,N); % centralized
ContStructure_decentralized = diag(ones(N,1)); % decentralized
% smart choice is to use info from first sub system to affect second
% controller (due to the inherent influence of the first to the second)
ContStructure_distributedString = [1    0;  
                                   1    1];

% OPEN LOOP EIGEN VALUES and SPECTRAL ABSCISSA
% CONTINUOUS
eigenvalues=eig(Atot); % eigen values 
rho=max(real(eig(Atot))); % spectral abscissa

% DISCRETE
eigenvalues_DT=eig(Ftot); % eigen values 
rho_DT=max(real(eig(Ftot))); % spectral abscissa

% State-feedback FIXED MODES
% Centralized
[cfm]=di_fixed_modes(Atot,B,C,N,ContStructure_centralized,3);
[cfm_DT]=di_fixed_modes(Ftot,G,H,N,ContStructure_centralized,3);
% Decentralized
[Dfm]=di_fixed_modes(Atot,B,C,N,ContStructure_decentralized,3);
[Dfm_DT]=di_fixed_modes(Ftot,G,H,N,ContStructure_decentralized,3);
% Distributed
[Distfm]=di_fixed_modes(Atot,B,C,N,ContStructure_distributedString,3);
[Distfm_DT]=di_fixed_modes(Ftot,G,H,N,ContStructure_distributedString,3); 

%% State-feedback control analysis:

% CENTRALIZED
[K_c,rho_c,feas_c]=LMI_CT_DeDicont(Atot,B,C,N,ContStructure_centralized);
[K_c_DT,rho_c_DT,feas_c_DT]=LMI_DT_DeDicont(Ftot,G,H,N,ContStructure_centralized);

% DECENTRALIZED
[K_De,rho_De,feas_De]=LMI_CT_DeDicont(Atot,B,C,N,ContStructure_decentralized);
[K_De_DT,rho_De_DT,feas_De_DT]=LMI_DT_DeDicont(Ftot,G,H,N,ContStructure_decentralized);

% DISTRIBUTED
[K_string,rho_string,feas_string]=LMI_CT_DeDicont(Atot,B,C,N,ContStructure_distributedString);
[K_string_DT,rho_string_DT,feas_string_DT]=LMI_DT_DeDicont(Ftot,G,H,N,ContStructure_distributedString);


