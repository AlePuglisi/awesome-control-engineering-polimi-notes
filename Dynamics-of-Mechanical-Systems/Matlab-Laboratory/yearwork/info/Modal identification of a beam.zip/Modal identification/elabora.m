close all
clear all

prove=1:10;
%prove=3;
npro=length(prove);
nnp=20;

im=menu('','Identification of the odd modes','Identification of the even modes');
if im==1
    str='c';
    imodi=[1 3 5];
else
    str='d';
    imodi=[2 4];
end
direct='';

for ipro=1:npro
    file=[direct str num2str(prove(ipro)) '.txt'];
    dataAcquired=load(file);
    
    vett_t=dataAcquired(:,1);
    F=dataAcquired(:,2);
    a1=dataAcquired(:,3);
    a2=dataAcquired(:,4);
    a3=dataAcquired(:,5);
    np=length(F);
    
    fs=np/(vett_t(end)-vett_t(1));
    f0=fs/np; df=f0; fmax=(np/2-1)*df;
    vett_f=0:df:fmax;
    
    implt=menu(file,'Plot the time histories','Skip');
    if implt==1
       figure
        subplot 411;plot(vett_t,F);grid;ylabel('Force [V]');title(file)
        subplot 412;plot(vett_t,a1);grid;ylabel('a1 [V]');title(file)
        subplot 413;plot(vett_t,a2);grid;ylabel('a2 [V]');title(file)
        subplot 414;plot(vett_t,a3);grid;ylabel('a3 [V]');title(file)
    end
    
    Fout=fft(F);
    modF(1)=abs(Fout(1))/np;
    modF(2:np/2)=abs(Fout(2:np/2))/np*2;
    fasF(1:np/2)=angle(Fout(1:np/2));
    fmax_plot=500; imax=round(fmax_plot/df);
    
    out=fft(a1);
    moda1(1)=abs(out(1))/np;
    moda1(2:np/2)=abs(out(2:np/2))/np*2;
    fasa1(1:np/2)=angle(out(1:np/2));
    
    out=fft(a2);
    moda2(1)=abs(out(1))/np;
    moda2(2:np/2)=abs(out(2:np/2))/np*2;
    fasa2(1:np/2)=angle(out(1:np/2));
    
    out=fft(a3);
    moda3(1)=abs(out(1))/np;
    moda3(2:np/2)=abs(out(2:np/2))/np*2;
    fasa3(1:np/2)=angle(out(1:np/2));

    i=sqrt(-1);
    if ipro==1
        H1=moda1./modF.*exp(i*(fasa1-fasF));
        H2=moda2./modF.*exp(i*(fasa2-fasF));
        H3=moda3./modF.*exp(i*(fasa3-fasF));
    else
        H1=H1+moda1./modF.*exp(i*(fasa1-fasF));
        H2=H2+moda2./modF.*exp(i*(fasa2-fasF));
        H3=H3+moda3./modF.*exp(i*(fasa3-fasF));
    end
end

H1=H1/npro; H2=H2/npro; H3=H3/npro;

iphase=menu('Range of the phase','-pi +pi','Unwrap');
if iphase==1
    phase1=angle(H1(1:imax));
    phase2=angle(H2(1:imax));
    phase3=angle(H3(1:imax));
else
    phase1=unwrap(angle(H1(1:imax)));
    phase2=unwrap(angle(H2(1:imax)));
    phase3=unwrap(angle(H3(1:imax)));
end

% df=fr(2)-fr(1);
fmax_plot=500; imax=round(fmax_plot/df);
figure
subplot 211; plot(vett_f(1:imax),abs(H1(1:imax)));grid;xlabel('frequency [Hz]');ylabel('[m/Ns^2]');title('a1/F')
subplot 212; plot(vett_f(1:imax),phase1);grid;xlabel('frequency [Hz]');ylabel('[rad]')
figure
subplot 211; plot(vett_f(1:imax),abs(H2(1:imax)));grid;xlabel('frequenza [Hz]');ylabel('[m/Ns^2]');title('a2/F')
subplot 212; plot(vett_f(1:imax),phase2);grid;xlabel('frequency [Hz]');ylabel('[rad]')
figure
subplot 211; plot(vett_f(1:imax),abs(H3(1:imax)));grid;xlabel('frequenza [Hz]');ylabel('[m/Ns^2]');title('a3/F')
subplot 212; plot(vett_f(1:imax),phase3);grid;xlabel('frequency [Hz]');ylabel('[rad]')

mod_H1=abs(H1);
mod_H2=abs(H2);
mod_H3=abs(H3);
fas_H1=angle(H1);
fas_H2=angle(H2);
fas_H3=angle(H3);

nmodi=5;
fini=[25 70 150 250 380];
ffin=[35 90 170 290 420];
x=[833.3 625.0 500.0 375.0 166.7]/1000;
sym=[1 -1 1 -1 1];

h=0.0059;
b=0.0502;
L=1.0;
rho=2700;
E=0.68e11;
A=b*h;
J=b*h^3/12;
m=rho*A;
csi=0:0.01:L;

for k=1:length(imodi)
    im=imodi(k);
    ini=round(fini(im)/df);
    fin=round(ffin(im)/df);
    if im==1
        [val imax]=max(mod_H1(ini:fin));
    else
        [val imax]=max(mod_H2(ini:fin));
    end
    imax=imax+ini-1;
    f0=vett_f(imax);
    if im==1
        p=polyfit(vett_f(imax-1:imax+1),unwrap(fas_H1(imax-1:imax+1)),1);
    else
        p=polyfit(vett_f(imax-1:imax+1),unwrap(fas_H2(imax-1:imax+1)),1);
    end
    dfi_df=-p(1);
    h=1/(dfi_df*f0);
    disp(['modo nr. ' num2str(im) ' f=' num2str(f0) ' [Hz]  h= ' num2str(h) ] )
    modo(1)=mod_H3(imax)*sin(fas_H3(imax)/180*pi);
    modo(2)=mod_H2(imax)*sin(fas_H2(imax)/180*pi);
    modo(3)=mod_H1(imax)*sin(fas_H1(imax)/180*pi);
    modo(4)=modo(2)*sym(im);
    modo(5)=modo(1)*sym(im);
    vm=max(abs(modo));
    modo=modo/vm;
    
    gamma=((f0*2*pi)^2*m/E/J)^0.25;
    for kk=1:5
        mtx_A(kk,1:4)=[sinh(gamma*x(kk)) cosh(gamma*x(kk)) sin(gamma*x(kk)) cos(gamma*x(kk))];
        vett_b(kk,1)=modo(kk);
    end
    vett_x=(mtx_A'*mtx_A)\(mtx_A'*vett_b);
    vett_y=vett_x(1)*sinh(gamma*csi)+vett_x(2)*cosh(gamma*csi)+vett_x(3)*sin(gamma*csi)+vett_x(4)*cos(gamma*csi);
    ymax=max(abs(vett_y)); vett_y=vett_y/ymax;

    figure;hold on
    plot(x,modo,[0 L],[0 0],'LineWidth',2);grid;axis([0 L -1 1]),title(['modo nr. ' num2str(im) ' f = ' num2str(f0) ' [Hz]'])
    plot(csi,vett_y,'r')
end
