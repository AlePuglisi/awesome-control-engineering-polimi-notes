clear all
%close all

h=0.0059;
b=0.0502;
L=1.0;
rho=2700;
E=0.68e11;
A=b*h;
J=b*h^3/12;

omega=[2.27 1.56 1.36 1.26].*[1 4 9 16]*pi^2/L^2*sqrt(E*J/rho/A);
freq=omega/2/pi

omega(5)=omega(4)/16*25/1.26*1.2;
gamma=(omega.^2*rho*A/E/J).^0.25;
options=optimset('fsolve');
dx=0.01;vettx=0:dx:L;

xvinc=[0.23 L-0.23 ];
xacc=[L/2 3*L/8 L/6 ];
indacc=round(length(vettx)*xacc/L);

nmodi=length(gamma);
figure(100)
hold on
color='brkgm';
for k=1:nmodi
    [g]=fsolve('funz_det',gamma(k),options,L);
    
    [err]=funz_det(g,L);
    ff(k)=g^2*sqrt(E*J/rho/A)/2/pi;
    
    gL=g*L;
    co=cos(gL);
    so=sin(gL);
    ci=cosh(gL);
    si=sinh(gL);
    g2=g^2;
    
    mtx_A=[-1 0 1 ;0 -1 0 ;-g2*co -g2*so g2*ci];
    vett_b=-[0;1;g2*si];
    coef=mtx_A\vett_b;
    disp('')
    disp([ 'modo ' num2str(k) ' freq= ' num2str(ff(k)) ' det=' num2str(err) 'coef ' num2str([coef' 1])]);
    disp('')
    coefA=coef(1);
    coefB=coef(2);
    coefC=coef(3);
    coefD=1;
    gx=g*vettx;
    vetty=coefA*cos(gx)+coefB*sin(gx)+coefC*cosh(gx)+coefD*sinh(gx);
    maxy=max(abs(vetty));
    vetty=vetty/maxy;
%     figure
%     plot(vettx,vetty)
%     grid
    figure(100)
    plot(vettx,vetty,color(k),'LineWidth',2)
    grid
    vetty(indacc);
end

plot([0 L],[0 0],'k--','LineWidth',3)
plot(xacc,[0 0 0],'r.','MarkerSize',36)
plot(xvinc,-0.05*[1 1 ],'k^','MarkerSize',12,'LineWidth',2)
axis([0 L -1 1]);
legend(num2str(ff'))
