function [err]=funz_det(g,L);

gL=g*L;
co=cos(gL);
so=sin(gL);
ci=cosh(gL);
si=sinh(gL);
g2=g^2;
g3=g^3;

mtx_A=[-1 0 1 0;0 -1 0 1;-g2*co -g2*so g2*ci g2*si;g3*so -g3*co g3*si g3*ci];
err=det(mtx_A);
